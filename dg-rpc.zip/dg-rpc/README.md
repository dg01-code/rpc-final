# dg-rpc

Java 原生 RPC 框架 - 毕业设计项目。

## 项目简介

dg-rpc 是一个轻量级 RPC 框架，支持服务注册与发现、远程调用、多种序列化、负载均衡、超时重试和简单容错，适合学习 RPC 原理及作为毕业设计项目。

## 架构图

```
                    客户端                                    服务端
    ┌─────────────────────────────────┐      ┌─────────────────────────────────┐
    │  RpcClientProxy (动态代理)        │      │  RpcServer (Netty)              │
    │         ↓                        │      │         ↓                        │
    │  LoadBalancer (负载均衡)          │      │  RequestHandler (请求分发)       │
    │         ↓                        │      │         ↓                        │
    │  Serializer (序列化)              │ ←──→ │  反射调用服务实现                │
    │         ↓                        │      │                                  │
    │  RpcClient (Netty)               │      │                                  │
    └──────────────┬──────────────────┘      └──────────────┬──────────────────┘
                   │                                         │
                   └───────────────┬─────────────────────────┘
                                   │
                         ┌────────▼────────┐
                         │  注册中心         │
                         │ (InMemory/ZK)   │
                         └─────────────────┘
```

## 模块说明

| 模块 | 说明 |
|------|------|
| dg-rpc-common | 公共：注解、异常、工具类 |
| dg-rpc-protocol | 协议：消息格式、序列化（Hessian/JSON）、编解码 |
| dg-rpc-registry | 注册中心：ServiceRegistry、ServiceDiscovery、InMemoryRegistry |
| dg-rpc-transport | 传输：Netty 服务端与客户端 |
| dg-rpc-core | 核心：动态代理、负载均衡、超时重试、容错 |
| dg-rpc-spring | Spring 集成：@RpcService、@RpcReference |
| dg-rpc-demo | 演示示例 |

## 快速开始

### 环境要求

- JDK 11+
- Maven 3.6+

### 编译

```bash
mvn clean install
```

### 运行简易演示

```bash
cd dg-rpc-demo
mvn exec:java -Dexec.mainClass="com.dg.rpc.demo.SimpleDemo"
```

### 运行 Spring 演示

```bash
cd dg-rpc-demo
mvn exec:java -Dexec.mainClass="com.dg.rpc.demo.SpringDemo"
```

## 使用方式

### 原生 API

```java
// 1. 创建注册中心
InMemoryRegistry registry = new InMemoryRegistry();

// 2. 启动服务端
RpcServerBootstrap server = new RpcServerBootstrap(8080, registry)
    .registerService(HelloService.class.getName(), new HelloServiceImpl());
server.start();

// 3. 创建客户端代理
HelloService proxy = RpcClientProxy.createProxy(HelloService.class, registry);

// 4. 远程调用
String result = proxy.sayHello("World");
```

### Spring 注解

```java
// 服务端
@RpcService
public class HelloServiceImpl implements HelloService { ... }

// 客户端
@Component
public class MyConsumer {
    @RpcReference
    private HelloService helloService;
}
```

## 核心特性

- **序列化**：Hessian（默认）、JSON，可扩展
- **负载均衡**：轮询、随机
- **超时与重试**：可配置连接超时、请求超时、重试次数与间隔
- **容错**：失败快速返回、异常传播

## 协议格式

```
魔数(4) | 版本(1) | 消息类型(1) | 序列化方式(1) | 请求ID(8) | 数据长度(4) | 数据体
```

## 许可证

MIT
