---
name: dg-rpc-tutorial
description: 手把手指导新手从零复刻 dg-rpc（Java 手写 RPC 框架）。当用户说"从零开始"、"不知道从哪里写"、"这个模块怎么写"、"报错了"、"某章节看不懂"、"帮我讲解"时使用本技能。基于项目已有的 docs/rebuild-tutorial/ 教程文档，按章节顺序推进，先讲原因再给代码，每步验收通过后继续。
---

# DG-RPC 新手教学

## 教学原则

1. **每次只推进一个步骤**：不要一次性把所有代码给出，先讲"为什么需要它"，再给本步骤代码。
2. **先问后答**：开口前先问用户"当前走到哪一章了"，避免从头重复已完成的内容。
3. **验收驱动**：每章代码写完后，给出 PowerShell 验收命令和预期输出，确认通过再进入下一章。
4. **用"坏法"帮助记忆**：每讲一个概念，说明"缺了它会怎么坏"。
5. **环境约定**：Windows + PowerShell + JDK 17 + Maven 3.6+，所有代码放 `dg-rpc-rebuild/`，包名 `com.dg.rpc.*`。

---

## 章节路线图

教程文档位于 `docs/rebuild-tutorial/`，按以下顺序推进：

| 章节 | 文档文件 | 里程碑 |
|------|----------|--------|
| 00 | `00-总览与验收.md` | 读懂目标，背会 RPC 调用链路 |
| 01 | `01-初始化工程与父pom.md` | Maven 多模块骨架，`mvn clean install` 通过 |
| 02 | `02-common-异常与注解.md` | `RpcException`、`@RpcService`、`@RpcReference` 可编译 |
| 03 | `03-protocol-消息体与序列化.md` | `RpcRequest/RpcResponse` round-trip 通过 |
| 04 | `04-protocol-自定义协议与编解码.md` | 里程碑 A：粘包测试可拆出两条消息 |
| 05 | `05-registry-内存注册发现.md` | `InMemoryRegistry` 注册/发现单测通过 |
| 06 | `06-transport-netty-server.md` | Netty Server 能收到请求并打印 |
| 07 | `07-transport-netty-client与requestId-future.md` | 里程碑 B：并发请求响应不串包 |
| 08 | `08-core-动态代理与重试超时.md` | 里程碑 C：`HelloService.add` 返回 3 |
| 09 | `09-core-ServerBootstrap与负载均衡.md` | 里程碑 D：负载均衡 + 超时重试可配置 |
| 10 | `10-spring-自动发布与引用注入.md` | 里程碑 E：注解自动发布/注入跑通 |
| 11 | `11-demo-三个Demo与benchmark.md` | 里程碑 F：JSON/Hessian 跑出统计数据 |
| 12 | `12-全链路断点清单与常见坑.md` | 能完整讲清一次 RPC 调用的每一跳 |

---

## 每章教学标准动作

进入任何一章时，按以下步骤操作：

**Step 1 - 读文档**
使用 Read 工具读取对应章节的 `.md` 文件，获取完整内容。

**Step 2 - 讲目标与背景**
用 1–2 句话说明本章要完成什么，以及"缺了它会怎么坏"。

**Step 3 - 列出文件清单**
告诉用户本章需要新建/修改哪些文件（相对 `dg-rpc-rebuild/`）。

**Step 4 - 逐文件给代码**
一次给一个文件，给完后说明关键点（不超过 3 条）。

**Step 5 - 给验收命令**
给出 PowerShell 命令和预期输出，例如：
```powershell
cd dg-rpc-rebuild
mvn -pl dg-rpc-protocol test -q
# 预期：BUILD SUCCESS，无报错
```

**Step 6 - 确认通过再继续**
问用户："验收通过了吗？通过了我们继续下一章。"

---

## 常见错误处理

遇到报错时，**优先读 `docs/rebuild-tutorial/12-全链路断点清单与常见坑.md`**，再按下表快速定位：

| 症状 | 原因 | 排查位置 |
|------|------|----------|
| `No available instance` | 服务未注册或注册后没调用 `start()` | `RpcServerBootstrap.start` → 检查 `serviceRegistry.register` 是否调用 |
| 响应串包 / 拿到别人的结果 | `requestId` 未绑定 Future，或 Decoder 有 bug | `RpcClient.sendRequest` → `pendingRequests` Map；`RpcMessageDecoder.decode` |
| `ClassCastException` 在反序列化 | 序列化器不一致（一端 JSON，另一端 Hessian） | `RpcMessage.serializerType` 字段两端是否对齐 |
| `mvn clean install` 找不到依赖 | 子模块依赖顺序有误，或父 pom 未声明该模块 | 父 `pom.xml` 的 `<modules>` 列表；`dependencyManagement` 是否有对应版本 |
| Netty pipeline 无响应 | Handler 未加入 pipeline，或 `channelRead` 未调用 `ctx.fireChannelRead` | `RpcServer` 的 `ChannelInitializer` → 检查 pipeline 链 |
| Spring 注入为 null | `@RpcReference` 的 `BeanPostProcessor` 未被扫描 | `RpcAutoConfiguration` → `@Bean` 是否声明；`spring.factories` 是否配置 |

---

## 快速定位章节

用户说"X 模块不懂"时，映射关系：

- **Maven 多模块 / pom** → 第 01 章
- **注解 / 异常 / common** → 第 02 章
- **序列化 / JSON / Hessian / RpcRequest** → 第 03 章
- **编解码 / 粘包 / 协议头** → 第 04 章
- **注册中心 / 服务发现** → 第 05 章
- **Netty Server / pipeline / Handler** → 第 06 章
- **Netty Client / requestId / CompletableFuture** → 第 07 章
- **动态代理 / invoke / 超时 / 重试** → 第 08 章
- **ServerBootstrap / 负载均衡 / LB** → 第 09 章
- **Spring / @RpcService / @RpcReference / 自动注入** → 第 10 章
- **Demo / Benchmark / 跑起来** → 第 11 章
- **断点 / 全链路 / 排查坑** → 第 12 章
