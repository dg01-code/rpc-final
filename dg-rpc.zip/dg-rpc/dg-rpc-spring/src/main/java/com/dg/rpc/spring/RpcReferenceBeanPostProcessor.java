package com.dg.rpc.spring;

import com.dg.rpc.common.annotation.RpcReference;
import com.dg.rpc.core.RpcClientProxy;
import com.dg.rpc.registry.ServiceDiscovery;
import org.springframework.beans.BeansException;
import org.springframework.beans.factory.config.BeanPostProcessor;

import java.lang.reflect.Field;

/**
 * 扫描 @RpcReference 注解，注入 RPC 代理
 */
public class RpcReferenceBeanPostProcessor implements BeanPostProcessor {

    private final ServiceDiscovery serviceDiscovery;

    public RpcReferenceBeanPostProcessor(ServiceDiscovery serviceDiscovery) {
        this.serviceDiscovery = serviceDiscovery;
    }

    @Override
    public Object postProcessAfterInitialization(Object bean, String beanName) throws BeansException {
        Class<?> clazz = bean.getClass();
        for (Field field : clazz.getDeclaredFields()) {
            if (field.isAnnotationPresent(RpcReference.class)) {
                field.setAccessible(true);
                try {
                    Object proxy = RpcClientProxy.createProxy(field.getType(), serviceDiscovery);
                    field.set(bean, proxy);
                } catch (IllegalAccessException e) {
                    throw new RuntimeException("Failed to inject RPC proxy for " + field.getName(), e);
                }
            }
        }
        return bean;
    }
}
