package com.dg.rpc.spring;

import com.dg.rpc.common.annotation.RpcService;
import com.dg.rpc.core.RpcServerBootstrap;
import com.dg.rpc.registry.ServiceRegistry;
import org.springframework.beans.BeansException;
import org.springframework.beans.factory.config.BeanPostProcessor;
import org.springframework.context.ApplicationContext;
import org.springframework.context.ApplicationContextAware;

import java.util.HashMap;
import java.util.Map;

/**
 * 扫描 @RpcService 注解，注册服务并启动 RPC 服务端
 */
public class RpcServiceBeanPostProcessor implements BeanPostProcessor, ApplicationContextAware {

    private ApplicationContext applicationContext;
    private final int port;
    private final ServiceRegistry serviceRegistry;
    private RpcServerBootstrap serverBootstrap;
    private final Map<String, Object> serviceMap = new HashMap<>();

    public RpcServiceBeanPostProcessor(int port, ServiceRegistry serviceRegistry) {
        this.port = port;
        this.serviceRegistry = serviceRegistry;
    }

    @Override
    public void setApplicationContext(ApplicationContext applicationContext) throws BeansException {
        this.applicationContext = applicationContext;
    }

    @Override
    public Object postProcessAfterInitialization(Object bean, String beanName) throws BeansException {
        if (bean.getClass().isAnnotationPresent(RpcService.class)) {
            Class<?>[] interfaces = bean.getClass().getInterfaces();
            if (interfaces.length > 0) {
                String serviceName = interfaces[0].getName();
                serviceMap.put(serviceName, bean);
            }
        }
        return bean;
    }

    public void startServer() {
        if (!serviceMap.isEmpty()) {
            serverBootstrap = new RpcServerBootstrap(port, serviceRegistry);
            for (Map.Entry<String, Object> entry : serviceMap.entrySet()) {
                serverBootstrap.registerService(entry.getKey(), entry.getValue());
            }
            serverBootstrap.start();
        }
    }

    public void shutdownServer() {
        if (serverBootstrap != null) {
            serverBootstrap.shutdown();
        }
    }
}
