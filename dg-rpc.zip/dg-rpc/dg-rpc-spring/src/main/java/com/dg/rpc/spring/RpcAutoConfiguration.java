package com.dg.rpc.spring;

import com.dg.rpc.registry.InMemoryRegistry;
import com.dg.rpc.registry.ServiceDiscovery;
import com.dg.rpc.registry.ServiceRegistry;
import com.dg.rpc.registry.ZookeeperRegistry;
import org.springframework.context.ApplicationListener;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.event.ContextRefreshedEvent;
import org.springframework.core.env.Environment;

import jakarta.annotation.PreDestroy;

/**
 * RPC Spring 自动配置。
 * 注册中心类型由配置 dg.rpc.registry.type 决定：memory（默认）或 zookeeper。
 */
@Configuration
public class RpcAutoConfiguration {

    private RpcServiceBeanPostProcessor serviceProcessor;
    private ZookeeperRegistry zookeeperRegistryForShutdown;

    @Bean
    public RpcRegistryProperties rpcRegistryProperties(Environment env) {
        RpcRegistryProperties p = new RpcRegistryProperties();
        p.setType(env.getProperty("dg.rpc.registry.type", "memory"));
        p.getZookeeper().setAddress(env.getProperty("dg.rpc.registry.zookeeper.address", "127.0.0.1:2181"));
        p.getZookeeper().setRootPath(env.getProperty("dg.rpc.registry.zookeeper.root-path", "/dg-rpc"));
        String st = env.getProperty("dg.rpc.registry.zookeeper.session-timeout-ms");
        if (st != null && !st.isEmpty()) {
            p.getZookeeper().setSessionTimeoutMs(Integer.parseInt(st.trim()));
        }
        return p;
    }

    @Bean
    public ServiceRegistry serviceRegistry(RpcRegistryProperties props) {
        String type = props.getType() == null ? "memory" : props.getType().trim().toLowerCase();
        if ("zookeeper".equals(type)) {
            RpcRegistryProperties.Zookeeper zk = props.getZookeeper();
            ZookeeperRegistry reg = new ZookeeperRegistry(
                    zk.getAddress(),
                    zk.getRootPath(),
                    zk.getSessionTimeoutMs()
            );
            reg.start();
            this.zookeeperRegistryForShutdown = reg;
            return reg;
        }
        return new InMemoryRegistry();
    }

    @Bean
    public ServiceDiscovery serviceDiscovery(ServiceRegistry serviceRegistry) {
        return (ServiceDiscovery) serviceRegistry;
    }

    @Bean
    public RpcReferenceBeanPostProcessor rpcReferenceBeanPostProcessor(ServiceDiscovery serviceDiscovery) {
        return new RpcReferenceBeanPostProcessor(serviceDiscovery);
    }

    @Bean
    public RpcServiceBeanPostProcessor rpcServiceBeanPostProcessor(ServiceRegistry serviceRegistry) {
        serviceProcessor = new RpcServiceBeanPostProcessor(8080, serviceRegistry);
        return serviceProcessor;
    }

    @Bean
    public ApplicationListener<ContextRefreshedEvent> rpcServerStarter(RpcServiceBeanPostProcessor processor) {
        return event -> processor.startServer();
    }

    @PreDestroy
    public void destroy() {
        if (serviceProcessor != null) {
            serviceProcessor.shutdownServer();
        }
        if (zookeeperRegistryForShutdown != null) {
            zookeeperRegistryForShutdown.close();
            zookeeperRegistryForShutdown = null;
        }
    }
}
