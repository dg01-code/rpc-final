package com.dg.rpc.spring;

/**
 * RPC 注册中心配置，从 dg.rpc.registry.* 绑定（通过 Environment 读取）。
 * 支持 application.properties / application.yml。
 */
public class RpcRegistryProperties {

    /** 注册中心类型：memory | zookeeper，默认 memory */
    private String type = "memory";

    private final Zookeeper zookeeper = new Zookeeper();

    public String getType() {
        return type;
    }

    public void setType(String type) {
        this.type = type == null ? "memory" : type.trim().toLowerCase();
    }

    public Zookeeper getZookeeper() {
        return zookeeper;
    }

    public static class Zookeeper {
        /** 连接串，必填当 type=zookeeper 时 */
        private String address = "127.0.0.1:2181";
        /** 根路径，默认 /dg-rpc */
        private String rootPath = "/dg-rpc";
        /** 会话超时毫秒，默认 60000 */
        private int sessionTimeoutMs = 60_000;

        public String getAddress() {
            return address;
        }

        public void setAddress(String address) {
            this.address = address;
        }

        public String getRootPath() {
            return rootPath;
        }

        public void setRootPath(String rootPath) {
            this.rootPath = rootPath;
        }

        public int getSessionTimeoutMs() {
            return sessionTimeoutMs;
        }

        public void setSessionTimeoutMs(int sessionTimeoutMs) {
            this.sessionTimeoutMs = sessionTimeoutMs;
        }
    }
}
