package com.dg.rpc.protocol.codec;

import com.dg.rpc.common.trace.RpcTrace;
import com.dg.rpc.protocol.message.RpcMessage;
import io.netty.buffer.ByteBuf;
import io.netty.channel.ChannelHandlerContext;
import io.netty.handler.codec.MessageToByteEncoder;

/**
 * RPC 消息编码器
 * 协议：魔数(4) + 版本(1) + 消息类型(1) + 序列化方式(1) + 请求ID(8) + 数据长度(4) + 数据体
 */
public class RpcMessageEncoder extends MessageToByteEncoder<RpcMessage> {

    @Override
    protected void encode(ChannelHandlerContext ctx, RpcMessage msg, ByteBuf out) {
        // trace: 真正进入 Netty 编码器（请求/响应都会走这里）
        try {
            if (msg != null && msg.getMessageType() != null) {
                switch (msg.getMessageType()) {
                    case REQUEST:
                        RpcTrace.emitByRequestId(msg.getRequestId(), 3, "enter", "netty encoder");
                        break;
                    case RESPONSE:
                        // 不额外点亮链路节点，留作调试信息
                        RpcTrace.emitByRequestId(msg.getRequestId(), 6, "enter", "server encoder response");
                        break;
                    default:
                        break;
                }
            }
        } catch (Exception ignored) {
            // tracing must never break codec
        }

        out.writeInt(msg.getMagic());
        out.writeByte(msg.getVersion());
        out.writeByte(msg.getMessageType().getCode());
        out.writeByte(msg.getSerializerType());
        out.writeLong(msg.getRequestId());

        byte[] data = msg.getData();
        int dataLen = data == null ? 0 : data.length;
        out.writeInt(dataLen);
        if (data != null && data.length > 0) {
            out.writeBytes(data);
        }
    }
}
