package com.dg.rpc.protocol.serializer;

/**
 * 序列化接口
 */
public interface Serializer {

    byte[] serialize(Object obj);

    <T> T deserialize(byte[] bytes, Class<T> clazz);
}
