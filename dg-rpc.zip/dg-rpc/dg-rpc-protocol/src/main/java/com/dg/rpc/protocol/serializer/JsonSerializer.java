package com.dg.rpc.protocol.serializer;

import com.dg.rpc.protocol.message.RpcRequest;
import com.dg.rpc.protocol.message.RpcResponse;
import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import com.google.gson.JsonArray;
import com.google.gson.JsonElement;
import com.google.gson.JsonObject;
import com.google.gson.JsonParser;
import com.google.gson.JsonPrimitive;
import com.google.gson.JsonParseException;

import java.lang.reflect.Type;
import java.nio.charset.StandardCharsets;

/**
 * JSON 序列化实现（使用 Gson）
 * 注意：JSON 对复杂类型（如 Class）支持有限，建议用于简单场景
 */
public class JsonSerializer implements Serializer {

    private static final Gson GSON = new GsonBuilder()
            .registerTypeAdapter(Class.class, new ClassCodec())
            .registerTypeHierarchyAdapter(Throwable.class, new ThrowableCodec())
            .create();

    @Override
    public byte[] serialize(Object obj) {
        if (obj instanceof RpcResponse) {
            return serializeRpcResponse((RpcResponse) obj);
        }
        return GSON.toJson(obj).getBytes(StandardCharsets.UTF_8);
    }

    @Override
    public <T> T deserialize(byte[] bytes, Class<T> clazz) {
        String json = new String(bytes, StandardCharsets.UTF_8);
        if (clazz == RpcRequest.class) {
            @SuppressWarnings("unchecked")
            T req = (T) deserializeRpcRequest(json);
            return req;
        }
        if (clazz == RpcResponse.class) {
            @SuppressWarnings("unchecked")
            T resp = (T) deserializeRpcResponse(json);
            return resp;
        }
        return GSON.fromJson(json, clazz);
    }

    private static RpcRequest deserializeRpcRequest(String json) {
        JsonObject obj = JsonParser.parseString(json).getAsJsonObject();
        String serviceName = getAsString(obj.get("serviceName"));
        String methodName = getAsString(obj.get("methodName"));

        JsonArray paramTypesJson = obj.getAsJsonArray("parameterTypes");
        Class<?>[] parameterTypes = new Class<?>[paramTypesJson == null ? 0 : paramTypesJson.size()];
        for (int i = 0; i < parameterTypes.length; i++) {
            parameterTypes[i] = resolveClass(getAsString(paramTypesJson.get(i)));
        }

        JsonArray argsJson = obj.getAsJsonArray("arguments");
        Object[] arguments = new Object[argsJson == null ? 0 : argsJson.size()];
        for (int i = 0; i < arguments.length; i++) {
            Class<?> paramType = i < parameterTypes.length ? parameterTypes[i] : Object.class;
            arguments[i] = GSON.fromJson(argsJson.get(i), paramType);
        }

        return new RpcRequest(serviceName, methodName, parameterTypes, arguments);
    }

    private static byte[] serializeRpcResponse(RpcResponse resp) {
        JsonObject obj = new JsonObject();
        obj.addProperty("requestId", resp.getRequestId());
        if (resp.getResult() == null) {
            obj.add("result", com.google.gson.JsonNull.INSTANCE);
        } else {
            obj.add("result", GSON.toJsonTree(resp.getResult()));
        }

        Throwable ex = resp.getException();
        if (ex != null) {
            JsonObject exObj = new JsonObject();
            exObj.addProperty("type", ex.getClass().getName());
            exObj.addProperty("message", ex.getMessage());
            obj.add("exception", exObj);
        } else {
            obj.add("exception", com.google.gson.JsonNull.INSTANCE);
        }

        return obj.toString().getBytes(StandardCharsets.UTF_8);
    }

    private static RpcResponse deserializeRpcResponse(String json) {
        JsonObject obj = JsonParser.parseString(json).getAsJsonObject();
        RpcResponse resp = new RpcResponse();
        JsonElement requestIdEl = obj.get("requestId");
        if (requestIdEl != null && !requestIdEl.isJsonNull()) {
            resp.setRequestId(requestIdEl.getAsLong());
        }

        JsonElement resultEl = obj.get("result");
        if (resultEl != null && !resultEl.isJsonNull()) {
            resp.setResult(GSON.fromJson(resultEl, Object.class));
        }

        JsonElement exEl = obj.get("exception");
        if (exEl != null && exEl.isJsonObject()) {
            JsonObject exObj = exEl.getAsJsonObject();
            String type = getAsString(exObj.get("type"));
            String message = getAsString(exObj.get("message"));
            String combined = (type == null ? "RemoteException" : type) + (message == null ? "" : (": " + message));
            resp.setException(new RuntimeException(combined));
        }
        return resp;
    }

    private static String getAsString(JsonElement el) {
        if (el == null || el.isJsonNull()) {
            return null;
        }
        return el.getAsString();
    }

    private static Class<?> resolveClass(String typeName) {
        if (typeName == null) {
            return Object.class;
        }
        switch (typeName) {
            case "boolean":
                return boolean.class;
            case "byte":
                return byte.class;
            case "short":
                return short.class;
            case "char":
                return char.class;
            case "int":
                return int.class;
            case "long":
                return long.class;
            case "float":
                return float.class;
            case "double":
                return double.class;
            case "void":
                return void.class;
            default:
                try {
                    return Class.forName(typeName);
                } catch (ClassNotFoundException e) {
                    return Object.class;
                }
        }
    }

    private static final class ClassCodec
            implements com.google.gson.JsonSerializer<Class<?>>, com.google.gson.JsonDeserializer<Class<?>> {
        @Override
        public JsonElement serialize(Class<?> src, Type typeOfSrc, com.google.gson.JsonSerializationContext context) {
            if (src == null) {
                return null;
            }
            if (src.isPrimitive()) {
                return new JsonPrimitive(src.getName());
            }
            return new JsonPrimitive(src.getName());
        }

        @Override
        public Class<?> deserialize(JsonElement json, Type typeOfT, com.google.gson.JsonDeserializationContext context)
                throws JsonParseException {
            if (json == null || json.isJsonNull()) {
                return Object.class;
            }
            return resolveClass(json.getAsString());
        }
    }

    private static final class ThrowableCodec
            implements com.google.gson.JsonSerializer<Throwable>, com.google.gson.JsonDeserializer<Throwable> {
        @Override
        public JsonElement serialize(Throwable src, Type typeOfSrc, com.google.gson.JsonSerializationContext context) {
            if (src == null) {
                return null;
            }
            JsonObject obj = new JsonObject();
            obj.addProperty("type", src.getClass().getName());
            obj.addProperty("message", src.getMessage());
            return obj;
        }

        @Override
        public Throwable deserialize(JsonElement json, Type typeOfT, com.google.gson.JsonDeserializationContext context)
                throws JsonParseException {
            if (json == null || json.isJsonNull()) {
                return null;
            }
            if (!json.isJsonObject()) {
                return new RuntimeException(String.valueOf(json));
            }
            JsonObject obj = json.getAsJsonObject();
            String type = getAsString(obj.get("type"));
            String message = getAsString(obj.get("message"));
            String combined = (type == null ? "RemoteException" : type) + (message == null ? "" : (": " + message));
            return new RuntimeException(combined);
        }
    }
}
