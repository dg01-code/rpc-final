package com.dg.rpc.protocol.serializer;

/**
 * 序列化类型
 */
public enum SerializerType {
    HESSIAN((byte) 1),
    JSON((byte) 2);

    private final byte code;

    SerializerType(byte code) {
        this.code = code;
    }

    public byte getCode() {
        return code;
    }

    public static SerializerType fromCode(byte code) {
        for (SerializerType type : values()) {
            if (type.code == code) {
                return type;
            }
        }
        throw new IllegalArgumentException("Unknown serializer type code: " + code);
    }
}
