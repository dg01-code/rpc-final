package com.dg.rpc.protocol.message;

import java.io.Serializable;

/**
 * RPC 响应体
 */
public class RpcResponse implements Serializable {

    private static final long serialVersionUID = 1L;

    private long requestId;
    private Object result;
    private Throwable exception;

    public RpcResponse() {
    }

    public RpcResponse(long requestId, Object result) {
        this.requestId = requestId;
        this.result = result;
    }

    public RpcResponse(long requestId, Throwable exception) {
        this.requestId = requestId;
        this.exception = exception;
    }

    public long getRequestId() {
        return requestId;
    }

    public void setRequestId(long requestId) {
        this.requestId = requestId;
    }

    public Object getResult() {
        return result;
    }

    public void setResult(Object result) {
        this.result = result;
    }

    public Throwable getException() {
        return exception;
    }

    public void setException(Throwable exception) {
        this.exception = exception;
    }

    public boolean hasException() {
        return exception != null;
    }
}
