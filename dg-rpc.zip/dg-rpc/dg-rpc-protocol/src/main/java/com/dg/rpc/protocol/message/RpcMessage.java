package com.dg.rpc.protocol.message;

import java.io.Serializable;

/**
 * RPC 消息体
 * 协议格式：魔数(4) + 版本(1) + 消息类型(1) + 序列化方式(1) + 请求ID(8) + 数据长度(4) + 数据体
 */
public class RpcMessage implements Serializable {

    private static final long serialVersionUID = 1L;

    public static final int MAGIC = 0x44475250; // DGPR

    private int magic = MAGIC;
    private byte version = 1;
    private MessageType messageType;
    private byte serializerType;
    private long requestId;
    private byte[] data;

    public RpcMessage() {
    }

    public RpcMessage(MessageType messageType, byte serializerType, long requestId, byte[] data) {
        this.messageType = messageType;
        this.serializerType = serializerType;
        this.requestId = requestId;
        this.data = data;
    }

    public int getMagic() {
        return magic;
    }

    public void setMagic(int magic) {
        this.magic = magic;
    }

    public byte getVersion() {
        return version;
    }

    public void setVersion(byte version) {
        this.version = version;
    }

    public MessageType getMessageType() {
        return messageType;
    }

    public void setMessageType(MessageType messageType) {
        this.messageType = messageType;
    }

    public byte getSerializerType() {
        return serializerType;
    }

    public void setSerializerType(byte serializerType) {
        this.serializerType = serializerType;
    }

    public long getRequestId() {
        return requestId;
    }

    public void setRequestId(long requestId) {
        this.requestId = requestId;
    }

    public byte[] getData() {
        return data;
    }

    public void setData(byte[] data) {
        this.data = data;
    }
}
