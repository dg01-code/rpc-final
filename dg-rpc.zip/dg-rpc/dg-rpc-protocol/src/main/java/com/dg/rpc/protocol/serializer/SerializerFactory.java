package com.dg.rpc.protocol.serializer;

import java.util.concurrent.ConcurrentHashMap;

/**
 * 序列化器工厂
 */
public class SerializerFactory {

    private static final ConcurrentHashMap<SerializerType, Serializer> CACHE = new ConcurrentHashMap<>();

    static {
        CACHE.put(SerializerType.HESSIAN, new HessianSerializer());
        CACHE.put(SerializerType.JSON, new JsonSerializer());
    }

    public static Serializer getSerializer(SerializerType type) {
        return CACHE.get(type);
    }

    public static Serializer getSerializer(byte code) {
        return getSerializer(SerializerType.fromCode(code));
    }
}
