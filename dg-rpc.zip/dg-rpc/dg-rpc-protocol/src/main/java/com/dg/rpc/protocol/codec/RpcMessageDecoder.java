package com.dg.rpc.protocol.codec;

import com.dg.rpc.common.exception.RpcException;
import com.dg.rpc.common.trace.RpcTrace;
import com.dg.rpc.protocol.message.MessageType;
import com.dg.rpc.protocol.message.RpcMessage;
import io.netty.buffer.ByteBuf;
import io.netty.channel.ChannelHandlerContext;
import io.netty.handler.codec.ByteToMessageDecoder;

import java.util.List;

/**
 * RPC 消息解码器
 * 协议：魔数(4) + 版本(1) + 消息类型(1) + 序列化方式(1) + 请求ID(8) + 数据长度(4) + 数据体
 */
public class RpcMessageDecoder extends ByteToMessageDecoder {

    private static final int HEAD_LENGTH = 4 + 1 + 1 + 1 + 8 + 4;

    @Override
    protected void decode(ChannelHandlerContext ctx, ByteBuf in, List<Object> out) {
        if (in.readableBytes() < HEAD_LENGTH) {
            return;
        }

        in.markReaderIndex();

        int magic = in.readInt();
        if (magic != RpcMessage.MAGIC) {
            throw new RpcException("Invalid magic number: " + magic);
        }

        byte version = in.readByte();
        byte msgTypeCode = in.readByte();
        byte serializerType = in.readByte();
        long requestId = in.readLong();
        int dataLength = in.readInt();

        if (in.readableBytes() < dataLength) {
            in.resetReaderIndex();
            return;
        }

        byte[] data = null;
        if (dataLength > 0) {
            data = new byte[dataLength];
            in.readBytes(data);
        }

        RpcMessage message = new RpcMessage();
        message.setMessageType(MessageType.fromCode(msgTypeCode));
        message.setSerializerType(serializerType);
        message.setRequestId(requestId);
        message.setData(data);

        // trace: 服务端解码/客户端解码（真实发生的位置）
        try {
            MessageType mt = message.getMessageType();
            if (mt == MessageType.REQUEST) {
                RpcTrace.emitByRequestId(requestId, 5, "enter", "server decode");
            } else if (mt == MessageType.RESPONSE) {
                // 这里不点亮链路节点，仅作为额外信息（前端可选择忽略）
                RpcTrace.emitByRequestId(requestId, 6, "enter", "client decode response");
            }
        } catch (Exception ignored) {
            // tracing must never break codec
        }

        out.add(message);
    }
}
