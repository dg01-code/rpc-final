package com.dg.rpc.demo;

import com.dg.rpc.demo.api.HelloService;
import org.springframework.context.annotation.AnnotationConfigApplicationContext;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.Import;
import org.springframework.context.annotation.PropertySource;

import com.dg.rpc.spring.RpcAutoConfiguration;

/**
 * Spring 集成演示。
 * 注册中心类型等配置见 src/main/resources/application.properties。
 */
public class SpringDemo {

    public static void main(String[] args) throws Exception {
        AnnotationConfigApplicationContext context =
                new AnnotationConfigApplicationContext(DemoConfig.class);

        Thread.sleep(1000); // 等待服务端启动

        HelloService helloService = context.getBean(ConsumerBean.class).getHelloService();
        System.out.println(">>> sayHello: " + helloService.sayHello("Spring"));
        System.out.println(">>> add: " + helloService.add(10, 20));
        if (helloService instanceof AutoCloseable) {
            ((AutoCloseable) helloService).close();
        }

        context.close();
    }

    @Configuration
    @PropertySource("classpath:application.properties")
    @Import(RpcAutoConfiguration.class)
    @ComponentScan("com.dg.rpc.demo")
    static class DemoConfig {
    }
}
