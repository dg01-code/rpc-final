package com.dg.rpc.demo;

/**
 * 答辩演示入口：一键启动 RPC 服务端（8080）+ HTTP 桥接层（8888）。
 * 启动后用浏览器打开项目根目录下的 demo.html 即可开始演示。
 */
public class DemoWebServer {

    public static void main(String[] args) throws Exception {
        DemoHttpServer server = new DemoHttpServer();
        server.start();

        Runtime.getRuntime().addShutdownHook(new Thread(() -> {
            System.out.println("正在关闭演示服务...");
            server.stop();
            System.out.println("已关闭。");
        }));

        // 保持主线程存活
        Thread.currentThread().join();
    }
}
