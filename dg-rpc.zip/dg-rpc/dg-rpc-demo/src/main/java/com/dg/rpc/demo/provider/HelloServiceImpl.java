package com.dg.rpc.demo.provider;

import com.dg.rpc.common.annotation.RpcService;
import com.dg.rpc.demo.api.HelloService;

/**
 * HelloService 实现
 */
@RpcService
public class HelloServiceImpl implements HelloService {

    @Override
    public String sayHello(String name) {
        return "Hello, " + name + "!";
    }

    @Override
    public int add(int a, int b) {
        return a + b;
    }
}
