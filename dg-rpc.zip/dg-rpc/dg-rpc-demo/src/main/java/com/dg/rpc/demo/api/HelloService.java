package com.dg.rpc.demo.api;

/**
 * 示例服务接口
 */
public interface HelloService {

    String sayHello(String name);

    int add(int a, int b);
}
