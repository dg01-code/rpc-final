package com.dg.rpc.demo;

import com.dg.rpc.common.annotation.RpcReference;
import com.dg.rpc.demo.api.HelloService;
import org.springframework.stereotype.Component;

/**
 * 消费者 Bean，通过 @RpcReference 注入远程服务
 */
@Component
public class ConsumerBean {

    @RpcReference
    private HelloService helloService;

    public HelloService getHelloService() {
        return helloService;
    }
}
