package com.dg.rpc.demo;

import com.dg.rpc.core.RpcClientProxy;
import com.dg.rpc.core.RpcServerBootstrap;
import com.dg.rpc.core.config.RpcClientConfig;
import com.dg.rpc.core.loadbalance.LoadBalancer;
import com.dg.rpc.core.loadbalance.RandomLoadBalancer;
import com.dg.rpc.core.loadbalance.RoundRobinLoadBalancer;
import com.dg.rpc.demo.api.HelloService;
import com.dg.rpc.demo.provider.HelloServiceImpl;
import com.dg.rpc.common.trace.RpcTrace;
import com.dg.rpc.protocol.serializer.SerializerType;
import com.dg.rpc.registry.InMemoryRegistry;
import com.dg.rpc.registry.ServiceDiscovery;
import com.dg.rpc.registry.ServiceRegistry;
import com.dg.rpc.registry.ZookeeperRegistry;
import com.google.gson.Gson;
import com.google.gson.JsonArray;
import com.google.gson.JsonObject;
import com.sun.net.httpserver.HttpExchange;
import com.sun.net.httpserver.HttpServer;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.net.InetSocketAddress;
import java.nio.charset.StandardCharsets;
import java.util.Arrays;
import java.util.UUID;
import java.util.concurrent.*;
import java.util.concurrent.atomic.AtomicInteger;
import java.util.concurrent.atomic.AtomicLong;

/**
 * HTTP 桥接层：同时启动 RPC 服务端和 HTTP 服务，让前端可通过 REST 接口触发真实 RPC 调用。
 *
 * <ul>
 *   <li>RPC  Server : 8080</li>
 *   <li>HTTP Bridge : 8888</li>
 * </ul>
 *
 * REST 接口：
 * <ul>
 *   <li>GET  /api/status    — 服务状态</li>
 *   <li>POST /api/invoke    — 触发一次 RPC 调用</li>
 *   <li>GET  /api/trace     — SSE 推送真实链路事件（traceId 关联）</li>
 *   <li>POST /api/benchmark — 运行小型基准测试</li>
 * </ul>
 */
public class DemoHttpServer {
    private static final Logger log = LoggerFactory.getLogger(DemoHttpServer.class);

    public static final int RPC_PORT  = 8080;
    public static final int HTTP_PORT = 8888;

    /** 注册中心：由 start() 根据配置创建（zookeeper 或 memory），stop() 时关闭 ZK。 */
    private ServiceRegistry        registry;
    private ZookeeperRegistry      zookeeperRegistry;
    private RpcServerBootstrap     rpcServer;
    private HttpServer             httpServer;

    // 预创建 4 个代理：2 种序列化 × 2 种负载均衡
    private HelloService hessianRrProxy;
    private HelloService jsonRrProxy;
    private HelloService hessianRandProxy;
    private HelloService jsonRandProxy;

    private final long       startTime  = System.currentTimeMillis();
    private final AtomicLong totalCalls = new AtomicLong(0);
    private final Gson       gson       = new Gson();

    // ── 启动 / 停止 ────────────────────────────────────────────────────────────

    public void start() throws Exception {
        initRegistry();
        rpcServer = new RpcServerBootstrap(RPC_PORT, registry)
                .registerService(HelloService.class.getName(), new HelloServiceImpl());
        rpcServer.start();
        Thread.sleep(500);

        hessianRrProxy   = newProxy(SerializerType.HESSIAN, new RoundRobinLoadBalancer());
        jsonRrProxy      = newProxy(SerializerType.JSON,    new RoundRobinLoadBalancer());
        hessianRandProxy = newProxy(SerializerType.HESSIAN, new RandomLoadBalancer());
        jsonRandProxy    = newProxy(SerializerType.JSON,    new RandomLoadBalancer());

        httpServer = HttpServer.create(new InetSocketAddress(HTTP_PORT), 32);
        httpServer.createContext("/api/status",    this::handleStatus);
        httpServer.createContext("/api/invoke",    this::handleInvoke);
        httpServer.createContext("/api/trace",     this::handleTrace);
        httpServer.createContext("/api/benchmark", this::handleBenchmark);
        httpServer.setExecutor(Executors.newFixedThreadPool(16));
        httpServer.start();
        log.info("Demo HTTP server started, rpcPort={}, httpPort={}", RPC_PORT, HTTP_PORT);

        System.out.println("================================================");
        System.out.println("  dg-rpc Demo Server Started!");
        System.out.println("  RPC  Server : localhost:" + RPC_PORT);
        System.out.println("  HTTP Bridge : http://localhost:" + HTTP_PORT);
        System.out.println("  用浏览器打开 demo.html 开始演示");
        System.out.println("================================================");
    }

    public void stop() {
        if (httpServer != null) httpServer.stop(1);
        closeProxy(hessianRrProxy);
        closeProxy(jsonRrProxy);
        closeProxy(hessianRandProxy);
        closeProxy(jsonRandProxy);
        if (rpcServer != null) rpcServer.shutdown();
        if (zookeeperRegistry != null) {
            log.info("Closing Zookeeper registry");
            zookeeperRegistry.close();
            zookeeperRegistry = null;
        }
    }

    /** 根据系统属性创建注册中心：dg.rpc.registry.type=zookeeper|memory，默认 zookeeper；ZK 地址等见 dg.rpc.registry.zookeeper.* */
    private void initRegistry() {
        String type = System.getProperty("dg.rpc.registry.type", "zookeeper").trim().toLowerCase();
        if ("zookeeper".equals(type)) {
            String address = System.getProperty("dg.rpc.registry.zookeeper.address", "172.18.83.27:2181");
            String rootPath = System.getProperty("dg.rpc.registry.zookeeper.root-path", "/dg-rpc");
            int sessionTimeoutMs = Integer.parseInt(System.getProperty("dg.rpc.registry.zookeeper.session-timeout-ms", "60000").trim());
            ZookeeperRegistry zk = new ZookeeperRegistry(address, rootPath, sessionTimeoutMs);
            zk.start();
            this.zookeeperRegistry = zk;
            this.registry = zk;
            log.info("Using Zookeeper registry: address={}, rootPath={}", address, rootPath);
        } else {
            this.registry = new InMemoryRegistry();
            log.info("Using in-memory registry");
        }
    }

    // ── 请求处理器 ────────────────────────────────────────────────────────────

    private void handleStatus(HttpExchange ex) throws IOException {
        if (!cors(ex)) return;
        if (!"GET".equals(ex.getRequestMethod())) { ex.sendResponseHeaders(405, -1); return; }
        log.info("HTTP {} {}", ex.getRequestMethod(), ex.getRequestURI());

        JsonObject r = new JsonObject();
        r.addProperty("status",     "running");
        r.addProperty("rpcPort",    RPC_PORT);
        r.addProperty("httpPort",   HTTP_PORT);
        r.addProperty("uptimeMs",   System.currentTimeMillis() - startTime);
        r.addProperty("totalCalls", totalCalls.get());

        JsonObject svc = new JsonObject();
        svc.addProperty("name",      "HelloService");
        svc.addProperty("interface", HelloService.class.getName());
        svc.addProperty("host",      "127.0.0.1");
        svc.addProperty("port",      RPC_PORT);
        JsonArray methods = new JsonArray();
        methods.add("String sayHello(String name)");
        methods.add("int add(int a, int b)");
        svc.add("methods", methods);
        JsonArray services = new JsonArray();
        services.add(svc);
        r.add("services", services);

        sendJson(ex, 200, gson.toJson(r));
    }

    private void handleInvoke(HttpExchange ex) throws IOException {
        if (!cors(ex)) return;
        if (!"POST".equals(ex.getRequestMethod())) { ex.sendResponseHeaders(405, -1); return; }

        String body = readBody(ex);
        JsonObject req  = gson.fromJson(body, JsonObject.class);
        String traceId  = optStr(req, "traceId", RpcTrace.newTraceId());
        String method   = optStr(req, "method",       "sayHello");
        String ser      = optStr(req, "serializer",   "HESSIAN");
        String lb       = optStr(req, "loadBalancer", "ROUND_ROBIN");
        JsonObject args = req.has("args") ? req.get("args").getAsJsonObject() : new JsonObject();
        log.info("HTTP {} {} traceId={} method={} serializer={} lb={} body={}",
                ex.getRequestMethod(), ex.getRequestURI(), traceId, method, ser, lb, body);

        HelloService proxy = pickProxy(ser, lb);
        long t0 = System.nanoTime();
        JsonObject resp = new JsonObject();

        int httpCode = 200;
        RpcTrace.ensureTrace(traceId);
        RpcTrace.setCurrentTraceId(traceId);
        RpcTrace.emit(traceId, null, 1, "enter", "HTTP bridge received");
        try {
            if (!"sayHello".equals(method) && !"add".equals(method)) {
                httpCode = 400;
                resp.addProperty("success", false);
                resp.addProperty("error", "Unknown method: " + method);
                resp.addProperty("traceId", traceId);
                RpcTrace.emit(traceId, null, 6, "error", "unknown method");
                return;
            }

            Object result;
            if ("sayHello".equals(method)) {
                String name = args.has("name") ? args.get("name").getAsString() : "World";
                result = proxy.sayHello(name);
            } else {
                int a = args.has("a") ? args.get("a").getAsInt() : 0;
                int b = args.has("b") ? args.get("b").getAsInt() : 0;
                result = proxy.add(a, b);
            }

            totalCalls.incrementAndGet();
            resp.addProperty("success",      true);
            resp.addProperty("result",       result.toString());
            resp.addProperty("method",       method);
            resp.addProperty("serializer",   ser.toUpperCase());
            resp.addProperty("loadBalancer", lb.toUpperCase());
            resp.addProperty("elapsedUs",    round1((System.nanoTime() - t0) / 1_000.0));
            resp.addProperty("traceId",      traceId);
            Long boundReqId = RpcTrace.getBoundRequestId(traceId);
            if (boundReqId != null) {
                resp.addProperty("requestId", boundReqId);
            } else {
                resp.addProperty("requestId", UUID.randomUUID().toString().replace("-", "").substring(0, 16).toUpperCase());
            }
            resp.add("protocolFrame",        buildFrame(ser, boundReqId));

            RpcTrace.emit(traceId, boundReqId, 6, "done", "rpc completed");
            log.info("Invoke success traceId={} method={} elapsedUs={}", traceId, method,
                    resp.get("elapsedUs").getAsDouble());

        } catch (Exception e) {
            resp.addProperty("success",   false);
            resp.addProperty("error",     getExceptionMessage(e));
            resp.addProperty("elapsedUs", round1((System.nanoTime() - t0) / 1_000.0));
            resp.addProperty("traceId",   traceId);
            RpcTrace.emit(traceId, RpcTrace.getBoundRequestId(traceId), 6, "error", "rpc failed");
            log.error("Invoke failed traceId={} method={} error={}", traceId, method, e.toString(), e);
        } finally {
            sendJson(ex, httpCode, gson.toJson(resp));
            RpcTrace.markDone(traceId);
            RpcTrace.clearCurrentTraceId();
        }
    }

    private void handleTrace(HttpExchange ex) throws IOException {
        if (!cors(ex)) return;
        if (!"GET".equals(ex.getRequestMethod())) { ex.sendResponseHeaders(405, -1); return; }

        String traceId = queryParam(ex.getRequestURI().getRawQuery(), "traceId");
        log.info("HTTP {} {} traceId={}", ex.getRequestMethod(), ex.getRequestURI(), traceId);
        if (traceId == null || traceId.isBlank()) {
            sendJson(ex, 400, "{\"error\":\"Missing traceId\"}");
            return;
        }

        RpcTrace.ensureTrace(traceId);

        ex.getResponseHeaders().set("Content-Type", "text/event-stream; charset=utf-8");
        ex.getResponseHeaders().set("Cache-Control", "no-cache");
        ex.getResponseHeaders().set("Connection", "keep-alive");
        ex.sendResponseHeaders(200, 0);

        try (OutputStream os = ex.getResponseBody()) {
            sseSend(os, "open", "{\"traceId\":\"" + traceId + "\"}");
            while (true) {
                if (RpcTrace.isDoneAndEmpty(traceId)) break;
                RpcTrace.TraceEvent ev;
                try {
                    ev = RpcTrace.poll(traceId, 15000);
                } catch (InterruptedException ie) {
                    Thread.currentThread().interrupt();
                    break;
                }
                if (ev == null) {
                    // keep-alive ping
                    os.write((": ping\n\n").getBytes(StandardCharsets.UTF_8));
                    os.flush();
                    continue;
                }
                sseSend(os, "trace", gson.toJson(ev));
            }
            sseSend(os, "done", "{\"traceId\":\"" + traceId + "\"}");
        } finally {
            RpcTrace.clearTrace(traceId);
        }
    }

    private void sseSend(OutputStream os, String event, String data) throws IOException {
        StringBuilder sb = new StringBuilder();
        if (event != null && !event.isBlank()) {
            sb.append("event: ").append(event).append('\n');
        }
        sb.append("data: ").append(data == null ? "" : data).append('\n');
        sb.append('\n');
        os.write(sb.toString().getBytes(StandardCharsets.UTF_8));
        os.flush();
    }

    private void handleBenchmark(HttpExchange ex) throws IOException {
        if (!cors(ex)) return;
        if (!"POST".equals(ex.getRequestMethod())) { ex.sendResponseHeaders(405, -1); return; }

        String body = readBody(ex);
        JsonObject req = gson.fromJson(body, JsonObject.class);
        String ser     = optStr(req, "serializer", "HESSIAN");
        int threads    = clamp(optInt(req, "threads", 4),  1, 20);
        int calls      = clamp(optInt(req, "calls",  1000), 100, 10000);
        int warmup     = Math.max(50, calls / 10);
        log.info("HTTP {} {} serializer={} threads={} calls={} body={}",
                ex.getRequestMethod(), ex.getRequestURI(), ser, threads, calls, body);

        RpcClientConfig cfg = new RpcClientConfig()
                .setSerializerType("JSON".equalsIgnoreCase(ser) ? SerializerType.JSON : SerializerType.HESSIAN)
                .setRequestTimeoutMs(15_000)
                .setRetries(0);
        HelloService bench = RpcClientProxy.createProxy(HelloService.class, (ServiceDiscovery) registry, new RoundRobinLoadBalancer(), cfg);

        try {
            for (int i = 0; i < warmup; i++) bench.add(1, 2);

            long[]        latNs  = new long[calls];
            AtomicInteger idx    = new AtomicInteger(0);
            CountDownLatch latch = new CountDownLatch(threads);
            ExecutorService pool = Executors.newFixedThreadPool(threads);
            int perThread = calls / threads, rem = calls % threads;

            long t0 = System.nanoTime();
            for (int t = 0; t < threads; t++) {
                int n = perThread + (t < rem ? 1 : 0);
                pool.execute(() -> {
                    try {
                        for (int i = 0; i < n; i++) {
                            long s = System.nanoTime();
                            bench.add(1, 2);
                            int at = idx.getAndIncrement();
                            if (at < latNs.length) latNs[at] = System.nanoTime() - s;
                        }
                    } finally { latch.countDown(); }
                });
            }
            latch.await(120, TimeUnit.SECONDS);
            double elapsedSec = (System.nanoTime() - t0) / 1e9;
            pool.shutdown();

            int    n       = Math.min(idx.get(), latNs.length);
            long[] samples = Arrays.copyOf(latNs, n);
            Arrays.sort(samples);
            long   sum     = 0;
            for (long v : samples) sum += v;

            JsonObject r = new JsonObject();
            r.addProperty("serializer", ser.toUpperCase());
            r.addProperty("threads",    threads);
            r.addProperty("calls",      calls);
            r.addProperty("throughput", round1(n / elapsedSec));
            r.addProperty("avgUs",      round2(n > 0 ? (sum / (double) n) / 1000.0 : 0));
            r.addProperty("p50Us",      round2(pctUs(samples, 50)));
            r.addProperty("p95Us",      round2(pctUs(samples, 95)));
            r.addProperty("p99Us",      round2(pctUs(samples, 99)));
            r.addProperty("maxUs",      round2(n > 0 ? samples[n - 1] / 1000.0 : 0));
            sendJson(ex, 200, gson.toJson(r));
            log.info("Benchmark done serializer={} threads={} calls={} throughput={}",
                    ser, threads, calls, r.get("throughput").getAsDouble());

        } catch (Exception e) {
            sendJson(ex, 500, "{\"error\":\"" + e.getMessage() + "\"}");
            log.error("Benchmark failed error={}", e.toString(), e);
        } finally {
            closeProxy(bench);
        }
    }

    // ── 工具方法 ──────────────────────────────────────────────────────────────

    private HelloService newProxy(SerializerType st, LoadBalancer lb) {
        RpcClientConfig cfg = new RpcClientConfig()
                .setSerializerType(st).setRequestTimeoutMs(5000).setRetries(0);
        return RpcClientProxy.createProxy(HelloService.class, (ServiceDiscovery) registry, lb, cfg);
    }

    private HelloService pickProxy(String ser, String lb) {
        boolean json = "JSON".equalsIgnoreCase(ser);
        boolean rand = "RANDOM".equalsIgnoreCase(lb);
        if (json && rand)  return jsonRandProxy;
        if (json)          return jsonRrProxy;
        if (rand)          return hessianRandProxy;
        return hessianRrProxy;
    }

    private void closeProxy(HelloService proxy) {
        if (proxy instanceof AutoCloseable) {
            try { ((AutoCloseable) proxy).close(); } catch (Exception ignored) {}
        }
    }

    /** 构造协议帧信息（用于前端可视化；requestId 为真实值，其他字段为近似展示） */
    private JsonObject buildFrame(String serializer, Long requestId) {
        JsonObject f = new JsonObject();
        f.addProperty("magic",          "0x44475250  \"DGRP\"  4 bytes");
        f.addProperty("version",        "0x01                  1 byte");
        f.addProperty("messageType",    "0x01  REQUEST         1 byte");
        f.addProperty("serializerType", "JSON".equalsIgnoreCase(serializer)
                ? "0x02  JSON           1 byte"
                : "0x01  HESSIAN        1 byte");
        if (requestId != null) {
            f.addProperty("requestId",  requestId + "          8 bytes");
        } else {
            f.addProperty("requestId",  (long) (Math.random() * 900000 + 100000) + "          8 bytes");
        }
        f.addProperty("dataLength",     "~60 ~ 120             4 bytes");
        f.addProperty("headerTotal",    "19 bytes");
        return f;
    }

    private String queryParam(String rawQuery, String key) {
        if (rawQuery == null || rawQuery.isBlank() || key == null || key.isBlank()) return null;
        String[] parts = rawQuery.split("&");
        for (String p : parts) {
            int i = p.indexOf('=');
            if (i <= 0) continue;
            String k = p.substring(0, i);
            if (!key.equals(k)) continue;
            return p.substring(i + 1);
        }
        return null;
    }

    private boolean cors(HttpExchange ex) throws IOException {
        ex.getResponseHeaders().add("Access-Control-Allow-Origin",  "*");
        ex.getResponseHeaders().add("Access-Control-Allow-Methods", "GET, POST, OPTIONS");
        ex.getResponseHeaders().add("Access-Control-Allow-Headers", "Content-Type");
        if ("OPTIONS".equals(ex.getRequestMethod())) {
            ex.sendResponseHeaders(204, -1);
            return false;
        }
        return true;
    }

    private void sendJson(HttpExchange ex, int code, String body) throws IOException {
        byte[] bytes = body.getBytes(StandardCharsets.UTF_8);
        ex.getResponseHeaders().set("Content-Type", "application/json; charset=utf-8");
        ex.sendResponseHeaders(code, bytes.length);
        try (OutputStream os = ex.getResponseBody()) { os.write(bytes); }
    }

    private String readBody(HttpExchange ex) throws IOException {
        try (InputStream is = ex.getRequestBody()) {
            return new String(is.readAllBytes(), StandardCharsets.UTF_8);
        }
    }

    private double pctUs(long[] sorted, int p) {
        if (sorted.length == 0) return 0;
        double rank = (p / 100.0) * (sorted.length - 1);
        int lo = (int) Math.floor(rank), hi = (int) Math.ceil(rank);
        if (lo == hi) return sorted[lo] / 1000.0;
        double w = rank - lo;
        return (sorted[lo] * (1 - w) + sorted[hi] * w) / 1000.0;
    }

    private String optStr(JsonObject o, String key, String def) {
        return o.has(key) ? o.get(key).getAsString() : def;
    }

    private int optInt(JsonObject o, String key, int def) {
        return o.has(key) ? o.get(key).getAsInt() : def;
    }

    private int clamp(int v, int min, int max) {
        return Math.min(Math.max(v, min), max);
    }

    private double round1(double v) { return Math.round(v * 10)   / 10.0; }
    private double round2(double v) { return Math.round(v * 100)  / 100.0; }

    /** 递归获取异常信息：优先 cause 链，getMessage 为 null 时用异常类名兜底 */
    private static String getExceptionMessage(Throwable t) {
        if (t == null) return "Unknown error";
        Throwable cause = t.getCause();
        if (cause != null && cause != t) {
            String causeMsg = getExceptionMessage(cause);
            if (causeMsg != null && !causeMsg.isEmpty()) return causeMsg;
        }
        String msg = t.getMessage();
        if (msg != null && !msg.trim().isEmpty()) return msg.trim();
        return t.getClass().getSimpleName();
    }
}
