package com.dg.rpc.demo;

import com.dg.rpc.core.RpcClientProxy;
import com.dg.rpc.core.RpcServerBootstrap;
import com.dg.rpc.demo.api.HelloService;
import com.dg.rpc.demo.provider.HelloServiceImpl;
import com.dg.rpc.registry.InMemoryRegistry;

/**
 * 简易演示：同一 JVM 内启动服务端与客户端，完成 RPC 调用
 */
public class SimpleDemo {

    public static void main(String[] args) throws Exception {
        InMemoryRegistry registry = new InMemoryRegistry();

        // 启动服务端
        RpcServerBootstrap server = new RpcServerBootstrap(8080, registry)
                .registerService(HelloService.class.getName(), new HelloServiceImpl());
        server.start();

        Thread.sleep(500); // 等待服务端就绪

        try {
            // 创建客户端代理并调用
            HelloService helloService = RpcClientProxy.createProxy(HelloService.class, registry);

            System.out.println(">>> sayHello: " + helloService.sayHello("World"));
            System.out.println(">>> add: " + helloService.add(1, 2));

            if (helloService instanceof AutoCloseable) {
                ((AutoCloseable) helloService).close();
            }
        } finally {
            server.shutdown();
        }
    }
}
