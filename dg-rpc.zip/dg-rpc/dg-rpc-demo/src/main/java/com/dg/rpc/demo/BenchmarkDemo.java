package com.dg.rpc.demo;

import com.dg.rpc.core.RpcClientProxy;
import com.dg.rpc.core.RpcServerBootstrap;
import com.dg.rpc.core.config.RpcClientConfig;
import com.dg.rpc.core.loadbalance.RoundRobinLoadBalancer;
import com.dg.rpc.demo.api.HelloService;
import com.dg.rpc.demo.provider.HelloServiceImpl;
import com.dg.rpc.protocol.serializer.SerializerType;
import com.dg.rpc.registry.InMemoryRegistry;

import java.util.Arrays;
import java.util.Locale;
import java.util.concurrent.CountDownLatch;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.TimeUnit;
import java.util.concurrent.atomic.AtomicInteger;

/**
 * 基准测试：在单机（loopback）下对 dg-rpc 做简单吞吐/延迟测量。
 * 注意：该基准不替代专业压测工具，仅用于毕业设计的可复现实验数据采集。
 */
public class BenchmarkDemo {

    public static void main(String[] args) throws Exception {
        int port = 8090;
        int threads = Math.max(2, Runtime.getRuntime().availableProcessors());
        int totalCalls = 50_000;
        int warmupCalls = 5_000;

        InMemoryRegistry registry = new InMemoryRegistry();
        RpcServerBootstrap server = new RpcServerBootstrap(port, registry)
                .registerService(HelloService.class.getName(), new HelloServiceImpl());
        server.start();
        Thread.sleep(800);

        try {
            printEnv();

            runOnce("HESSIAN", SerializerType.HESSIAN, registry, threads, warmupCalls, totalCalls);
            runOnce("JSON", SerializerType.JSON, registry, threads, warmupCalls, totalCalls);
        } finally {
            server.shutdown();
        }
    }

    private static void runOnce(String label, SerializerType serializerType, InMemoryRegistry registry,
                                int threads, int warmupCalls, int totalCalls) throws Exception {
        RpcClientConfig config = new RpcClientConfig()
                .setSerializerType(serializerType)
                .setRequestTimeoutMs(5_000)
                .setConnectTimeoutMs(3_000)
                .setRetries(0);

        HelloService helloService = RpcClientProxy.createProxy(
                HelloService.class,
                registry,
                new RoundRobinLoadBalancer(),
                config
        );

        try {
            // warmup
            for (int i = 0; i < warmupCalls; i++) {
                helloService.add(1, 2);
            }

            Stats stats = runParallel(helloService, threads, totalCalls);
            System.out.println();
            System.out.println("==== Benchmark (" + label + ") ====");
            System.out.println("threads=" + threads + ", totalCalls=" + totalCalls + ", warmupCalls=" + warmupCalls);
            System.out.printf(Locale.ROOT, "throughput=%.1f ops/s, avg=%.2f us, p50=%.2f us, p95=%.2f us, p99=%.2f us, max=%.2f us%n",
                    stats.throughputOpsPerSec,
                    stats.avgUs,
                    stats.p50Us,
                    stats.p95Us,
                    stats.p99Us,
                    stats.maxUs
            );
        } finally {
            if (helloService instanceof AutoCloseable) {
                ((AutoCloseable) helloService).close();
            }
        }
    }

    private static Stats runParallel(HelloService helloService, int threads, int totalCalls) throws Exception {
        long[] latenciesNs = new long[totalCalls];
        AtomicInteger idx = new AtomicInteger(0);

        ExecutorService pool = Executors.newFixedThreadPool(threads);
        CountDownLatch latch = new CountDownLatch(threads);

        int callsPerThread = totalCalls / threads;
        int remainder = totalCalls % threads;

        long benchStartNs = System.nanoTime();
        for (int t = 0; t < threads; t++) {
            int calls = callsPerThread + (t < remainder ? 1 : 0);
            pool.execute(() -> {
                try {
                    for (int i = 0; i < calls; i++) {
                        long s = System.nanoTime();
                        int r = helloService.add(1, 2);
                        long e = System.nanoTime();
                        if (r != 3) {
                            throw new IllegalStateException("Unexpected result: " + r);
                        }
                        int at = idx.getAndIncrement();
                        if (at < latenciesNs.length) {
                            latenciesNs[at] = e - s;
                        }
                    }
                } finally {
                    latch.countDown();
                }
            });
        }

        latch.await(120, TimeUnit.SECONDS);
        long benchEndNs = System.nanoTime();

        pool.shutdown();
        pool.awaitTermination(10, TimeUnit.SECONDS);

        int n = Math.min(idx.get(), latenciesNs.length);
        if (n <= 0) {
            throw new IllegalStateException("No samples collected");
        }

        long[] samples = Arrays.copyOf(latenciesNs, n);
        Arrays.sort(samples);

        double elapsedSec = (benchEndNs - benchStartNs) / 1_000_000_000.0;
        double throughput = n / elapsedSec;

        long sum = 0;
        for (long v : samples) {
            sum += v;
        }

        Stats s = new Stats();
        s.throughputOpsPerSec = throughput;
        s.avgUs = (sum / (double) n) / 1_000.0;
        s.p50Us = percentileUs(samples, 50);
        s.p95Us = percentileUs(samples, 95);
        s.p99Us = percentileUs(samples, 99);
        s.maxUs = samples[n - 1] / 1_000.0;
        return s;
    }

    private static double percentileUs(long[] sortedNs, int p) {
        if (sortedNs.length == 0) {
            return 0;
        }
        double rank = (p / 100.0) * (sortedNs.length - 1);
        int lo = (int) Math.floor(rank);
        int hi = (int) Math.ceil(rank);
        if (lo == hi) {
            return sortedNs[lo] / 1_000.0;
        }
        double w = rank - lo;
        return (sortedNs[lo] * (1 - w) + sortedNs[hi] * w) / 1_000.0;
    }

    private static void printEnv() {
        System.out.println("==== Environment ====");
        System.out.println("os.name=" + System.getProperty("os.name") + ", os.version=" + System.getProperty("os.version"));
        System.out.println("java.version=" + System.getProperty("java.version") + ", java.vendor=" + System.getProperty("java.vendor"));
        System.out.println("availableProcessors=" + Runtime.getRuntime().availableProcessors());
    }

    private static final class Stats {
        double throughputOpsPerSec;
        double avgUs;
        double p50Us;
        double p95Us;
        double p99Us;
        double maxUs;
    }
}

