package com.dg.rpc.common.trace;

import java.util.Objects;
import java.util.UUID;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.LinkedBlockingQueue;
import java.util.concurrent.TimeUnit;

/**
 * 一个极简的“演示用”链路追踪事件总线：
 * - 由 DemoHttpServer 设置 traceId（ThreadLocal）
 * - RpcClient 在生成 requestId 后，把 requestId ↔ traceId 绑定起来
 * - 编码/解码/服务端处理等位置只拿得到 requestId，也能反查到 traceId 并发事件
 *
 * 注意：这是 demo 可视化用途，不做跨进程传播。
 */
public final class RpcTrace {

    private RpcTrace() {}

    public static final class TraceEvent {
        public final String traceId;
        public final Long requestId;
        public final int step;
        public final String phase; // enter | done | error
        public final String detail;
        public final long ts;

        public TraceEvent(String traceId, Long requestId, int step, String phase, String detail, long ts) {
            this.traceId = traceId;
            this.requestId = requestId;
            this.step = step;
            this.phase = phase;
            this.detail = detail;
            this.ts = ts;
        }

        public static TraceEvent now(String traceId, Long requestId, int step, String phase, String detail) {
            return new TraceEvent(traceId, requestId, step, phase, detail, System.currentTimeMillis());
        }
    }

    private static final class TraceStream {
        final LinkedBlockingQueue<TraceEvent> q = new LinkedBlockingQueue<>();
        volatile boolean done = false;
    }

    private static final ThreadLocal<String> CURRENT_TRACE = new ThreadLocal<>();
    private static final ConcurrentHashMap<String, TraceStream> STREAMS = new ConcurrentHashMap<>();
    private static final ConcurrentHashMap<Long, String> REQ_TO_TRACE = new ConcurrentHashMap<>();
    private static final ConcurrentHashMap<String, Long> TRACE_TO_REQ = new ConcurrentHashMap<>();

    public static String newTraceId() {
        return UUID.randomUUID().toString().replace("-", "");
    }

    public static void setCurrentTraceId(String traceId) {
        if (traceId == null || traceId.isBlank()) return;
        CURRENT_TRACE.set(traceId);
        ensureTrace(traceId);
    }

    public static String getCurrentTraceId() {
        return CURRENT_TRACE.get();
    }

    public static void clearCurrentTraceId() {
        CURRENT_TRACE.remove();
    }

    public static void ensureTrace(String traceId) {
        if (traceId == null || traceId.isBlank()) return;
        STREAMS.computeIfAbsent(traceId, k -> new TraceStream());
    }

    public static void bindRequestIdToCurrentTrace(long requestId) {
        String traceId = getCurrentTraceId();
        if (traceId == null) return;
        REQ_TO_TRACE.put(requestId, traceId);
        TRACE_TO_REQ.putIfAbsent(traceId, requestId);
        ensureTrace(traceId);
    }

    public static Long getBoundRequestId(String traceId) {
        if (traceId == null) return null;
        return TRACE_TO_REQ.get(traceId);
    }

    public static void emitToCurrent(int step, String phase, String detail) {
        String traceId = getCurrentTraceId();
        if (traceId == null) return;
        emit(traceId, null, step, phase, detail);
    }

    public static void emitByRequestId(long requestId, int step, String phase, String detail) {
        String traceId = REQ_TO_TRACE.get(requestId);
        if (traceId == null) return;
        emit(traceId, requestId, step, phase, detail);
    }

    public static void emit(String traceId, Long requestId, int step, String phase, String detail) {
        if (traceId == null || traceId.isBlank()) return;
        Objects.requireNonNull(phase, "phase");
        TraceStream s = STREAMS.get(traceId);
        if (s == null) return;
        s.q.offer(TraceEvent.now(traceId, requestId, step, phase, detail));
    }

    public static TraceEvent poll(String traceId, long timeoutMs) throws InterruptedException {
        TraceStream s = STREAMS.get(traceId);
        if (s == null) return null;
        return s.q.poll(timeoutMs, TimeUnit.MILLISECONDS);
    }

    public static boolean isDoneAndEmpty(String traceId) {
        TraceStream s = STREAMS.get(traceId);
        if (s == null) return true;
        return s.done && s.q.isEmpty();
    }

    public static void markDone(String traceId) {
        TraceStream s = STREAMS.get(traceId);
        if (s == null) return;
        s.done = true;
    }

    public static void clearTrace(String traceId) {
        if (traceId == null) return;
        STREAMS.remove(traceId);
        Long reqId = TRACE_TO_REQ.remove(traceId);
        if (reqId != null) {
            REQ_TO_TRACE.remove(reqId);
        }
    }
}

