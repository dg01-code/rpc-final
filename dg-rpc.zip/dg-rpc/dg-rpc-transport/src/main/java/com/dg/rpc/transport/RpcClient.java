package com.dg.rpc.transport;

import com.dg.rpc.common.trace.RpcTrace;
import com.dg.rpc.protocol.message.MessageType;
import com.dg.rpc.protocol.message.RpcMessage;
import com.dg.rpc.protocol.message.RpcRequest;
import com.dg.rpc.protocol.message.RpcResponse;
import com.dg.rpc.protocol.serializer.Serializer;
import com.dg.rpc.protocol.serializer.SerializerFactory;
import com.dg.rpc.protocol.serializer.SerializerType;
import io.netty.bootstrap.Bootstrap;
import io.netty.channel.Channel;
import io.netty.channel.ChannelFuture;
import io.netty.channel.ChannelOption;
import io.netty.channel.ChannelInitializer;
import io.netty.channel.ChannelPipeline;
import io.netty.channel.nio.NioEventLoopGroup;
import io.netty.channel.socket.SocketChannel;
import io.netty.channel.socket.nio.NioSocketChannel;
import io.netty.handler.timeout.IdleStateHandler;

import java.net.InetSocketAddress;
import java.util.concurrent.CompletableFuture;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.TimeUnit;
import java.util.concurrent.atomic.AtomicLong;

/**
 * RPC 客户端（基于 Netty）
 */
public class RpcClient {

    private final NioEventLoopGroup group = new NioEventLoopGroup();
    private final Bootstrap bootstrap = new Bootstrap();
    private final ConcurrentHashMap<String, Channel> channelMap = new ConcurrentHashMap<>();
    private final AtomicLong requestIdGen = new AtomicLong(0);
    private final SerializerType serializerType;
    private final int connectTimeoutMs;
    private final int requestTimeoutMs;

    public RpcClient() {
        this(SerializerType.HESSIAN, 3000, 5000);
    }

    public RpcClient(SerializerType serializerType, int connectTimeoutMs, int requestTimeoutMs) {
        this.serializerType = serializerType;
        this.connectTimeoutMs = connectTimeoutMs;
        this.requestTimeoutMs = requestTimeoutMs;

        bootstrap.group(group)
                .channel(NioSocketChannel.class)
                .option(ChannelOption.CONNECT_TIMEOUT_MILLIS, connectTimeoutMs)
                .handler(new ChannelInitializer<SocketChannel>() {
                    @Override
                    protected void initChannel(SocketChannel ch) {
                        ChannelPipeline p = ch.pipeline();
                        p.addLast(new IdleStateHandler(0, 0, 30, TimeUnit.SECONDS));
                        p.addLast(new com.dg.rpc.protocol.codec.RpcMessageDecoder());
                        p.addLast(new com.dg.rpc.protocol.codec.RpcMessageEncoder());
                        p.addLast(new RpcClientHandler());
                    }
                });
    }

    public RpcResponse sendRequest(String host, int port, RpcRequest request) {
        String address = host + ":" + port;
        Channel channel = getOrCreateChannel(host, port);
        if (channel == null || !channel.isActive()) {
            throw new com.dg.rpc.common.exception.RpcException("Failed to connect to " + address);
        }

        // trace: 序列化/编码阶段开始（真实发生的位置）
        RpcTrace.emitToCurrent(3, "enter", "serialize+encode");

        long requestId = requestIdGen.incrementAndGet();
        RpcTrace.bindRequestIdToCurrentTrace(requestId);

        Serializer serializer = SerializerFactory.getSerializer(serializerType);
        byte[] data = serializer.serialize(request);

        RpcMessage message = new RpcMessage(MessageType.REQUEST, serializerType.getCode(), requestId, data);

        CompletableFuture<RpcResponse> future = new CompletableFuture<>();
        RpcClientHandler.addPendingRequest(requestId, future);

        // trace: Netty 发送（真实发生的位置）
        ChannelFuture f = channel.writeAndFlush(message);
        RpcTrace.emitByRequestId(requestId, 4, "enter", "netty writeAndFlush");
        f.addListener(cf -> {
            if (!cf.isSuccess()) {
                RpcTrace.emitByRequestId(requestId, 4, "error", "netty send failed");
            }
        });

        try {
            return future.get(requestTimeoutMs, TimeUnit.MILLISECONDS);
        } catch (Exception e) {
            RpcClientHandler.removePendingRequest(requestId);
            throw new com.dg.rpc.common.exception.RpcException("Request timeout or failed: " + address, e);
        }
    }

    private Channel getOrCreateChannel(String host, int port) {
        String key = host + ":" + port;
        return channelMap.computeIfAbsent(key, k -> {
            try {
                ChannelFuture future = bootstrap.connect(new InetSocketAddress(host, port))
                        .sync();
                return future.channel();
            } catch (InterruptedException e) {
                Thread.currentThread().interrupt();
                throw new com.dg.rpc.common.exception.RpcException("Connect failed", e);
            }
        });
    }

    public void close() {
        channelMap.values().forEach(Channel::close);
        group.shutdownGracefully();
    }
}
