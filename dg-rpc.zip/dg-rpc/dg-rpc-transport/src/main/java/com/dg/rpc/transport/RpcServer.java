package com.dg.rpc.transport;

import com.dg.rpc.protocol.codec.RpcMessageDecoder;
import com.dg.rpc.protocol.codec.RpcMessageEncoder;
import com.dg.rpc.protocol.message.MessageType;
import com.dg.rpc.protocol.message.RpcMessage;
import com.dg.rpc.protocol.message.RpcRequest;
import com.dg.rpc.protocol.message.RpcResponse;
import com.dg.rpc.protocol.serializer.Serializer;
import com.dg.rpc.protocol.serializer.SerializerFactory;
import com.dg.rpc.protocol.serializer.SerializerType;
import io.netty.bootstrap.ServerBootstrap;
import io.netty.channel.ChannelFuture;
import io.netty.channel.ChannelHandlerContext;
import io.netty.channel.ChannelInboundHandlerAdapter;
import io.netty.channel.ChannelInitializer;
import io.netty.channel.ChannelPipeline;
import io.netty.channel.nio.NioEventLoopGroup;
import io.netty.channel.socket.SocketChannel;
import io.netty.channel.socket.nio.NioServerSocketChannel;
import io.netty.handler.timeout.IdleState;
import io.netty.handler.timeout.IdleStateEvent;
import io.netty.handler.timeout.IdleStateHandler;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.util.Map;
import java.util.concurrent.TimeUnit;

/**
 * RPC 服务端（基于 Netty）
 */
public class RpcServer {

    private static final Logger log = LoggerFactory.getLogger(RpcServer.class);

    private final int port;
    private final Map<String, Object> serviceMap;
    private final RequestHandler requestHandler;
    private NioEventLoopGroup bossGroup;
    private NioEventLoopGroup workerGroup;

    public RpcServer(int port, Map<String, Object> serviceMap) {
        this.port = port;
        this.serviceMap = serviceMap;
        this.requestHandler = new RequestHandler(serviceMap);
    }

    public void start() {
        bossGroup = new NioEventLoopGroup(1);
        workerGroup = new NioEventLoopGroup();

        try {
            ServerBootstrap bootstrap = new ServerBootstrap();
            bootstrap.group(bossGroup, workerGroup)
                    .channel(NioServerSocketChannel.class)
                    .childHandler(new ChannelInitializer<SocketChannel>() {
                        @Override
                        protected void initChannel(SocketChannel ch) {
                            ChannelPipeline p = ch.pipeline();
                            p.addLast(new IdleStateHandler(0, 0, 60, TimeUnit.SECONDS));
                            p.addLast(new RpcMessageDecoder());
                            p.addLast(new RpcMessageEncoder());
                            p.addLast(new RpcServerHandler());
                        }
                    });

            ChannelFuture future = bootstrap.bind(port).sync();
            log.info("RPC Server started on port {}", port);
        } catch (InterruptedException e) {
            Thread.currentThread().interrupt();
            throw new com.dg.rpc.common.exception.RpcException("Server start failed", e);
        }
    }

    public void shutdown() {
        if (bossGroup != null) {
            bossGroup.shutdownGracefully();
        }
        if (workerGroup != null) {
            workerGroup.shutdownGracefully();
        }
    }

    private class RpcServerHandler extends ChannelInboundHandlerAdapter {

        @Override
        public void channelRead(ChannelHandlerContext ctx, Object msg) {
            if (!(msg instanceof RpcMessage)) {
                return;
            }

            RpcMessage message = (RpcMessage) msg;
            if (message.getMessageType() != MessageType.REQUEST) {
                return;
            }

            Serializer serializer = SerializerFactory.getSerializer(message.getSerializerType());
            RpcRequest request = serializer.deserialize(message.getData(), RpcRequest.class);
            RpcResponse response = requestHandler.handle(request, message.getRequestId());

            byte[] data = serializer.serialize(response);
            RpcMessage respMsg = new RpcMessage(MessageType.RESPONSE, message.getSerializerType(),
                    message.getRequestId(), data);
            ctx.writeAndFlush(respMsg);
        }

        @Override
        public void userEventTriggered(ChannelHandlerContext ctx, Object evt) {
            if (evt instanceof IdleStateEvent) {
                IdleStateEvent event = (IdleStateEvent) evt;
                if (event.state() == IdleState.ALL_IDLE) {
                    ctx.close();
                }
            } else {
                ctx.fireUserEventTriggered(evt);
            }
        }

        @Override
        public void exceptionCaught(ChannelHandlerContext ctx, Throwable cause) {
            log.error("Server handler error", cause);
            ctx.close();
        }
    }
}
