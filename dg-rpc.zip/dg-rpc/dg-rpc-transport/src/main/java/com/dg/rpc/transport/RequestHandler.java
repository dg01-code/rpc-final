package com.dg.rpc.transport;

import com.dg.rpc.common.trace.RpcTrace;
import com.dg.rpc.protocol.message.RpcRequest;
import com.dg.rpc.protocol.message.RpcResponse;

import java.lang.reflect.Method;
import java.util.Map;

/**
 * 服务端请求处理器
 */
public class RequestHandler {

    private final Map<String, Object> serviceMap;

    public RequestHandler(Map<String, Object> serviceMap) {
        this.serviceMap = serviceMap;
    }

    public RpcResponse handle(RpcRequest request, long requestId) {
        try {
            // trace: 反射调用（真实发生的位置）
            RpcTrace.emitByRequestId(requestId, 6, "enter", "reflect invoke " + request.getMethodName());

            String serviceName = request.getServiceName();
            Object service = serviceMap.get(serviceName);
            if (service == null) {
                return new RpcResponse(requestId, new com.dg.rpc.common.exception.RpcException("Service not found: " + serviceName));
            }

            Method method = service.getClass().getMethod(
                    request.getMethodName(),
                    request.getParameterTypes()
            );
            Object result = method.invoke(service, request.getArguments());
            return new RpcResponse(requestId, result);
        } catch (Exception e) {
            return new RpcResponse(requestId, e.getCause() != null ? e.getCause() : e);
        }
    }
}
