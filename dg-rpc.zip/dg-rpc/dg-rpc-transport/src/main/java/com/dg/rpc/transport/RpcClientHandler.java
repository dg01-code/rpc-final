package com.dg.rpc.transport;

import com.dg.rpc.protocol.message.MessageType;
import com.dg.rpc.protocol.message.RpcMessage;
import com.dg.rpc.protocol.message.RpcResponse;
import com.dg.rpc.protocol.serializer.SerializerFactory;
import io.netty.channel.ChannelHandlerContext;
import io.netty.channel.ChannelInboundHandlerAdapter;
import io.netty.handler.timeout.IdleState;
import io.netty.handler.timeout.IdleStateEvent;

import java.util.concurrent.CompletableFuture;
import java.util.concurrent.ConcurrentHashMap;

/**
 * RPC 客户端处理器
 */
public class RpcClientHandler extends ChannelInboundHandlerAdapter {

    private static final ConcurrentHashMap<Long, CompletableFuture<RpcResponse>> PENDING_REQUESTS = new ConcurrentHashMap<>();

    public static void addPendingRequest(long requestId, CompletableFuture<RpcResponse> future) {
        PENDING_REQUESTS.put(requestId, future);
    }

    public static void removePendingRequest(long requestId) {
        PENDING_REQUESTS.remove(requestId);
    }

    @Override
    public void channelRead(ChannelHandlerContext ctx, Object msg) {
        if (!(msg instanceof RpcMessage)) {
            return;
        }

        RpcMessage message = (RpcMessage) msg;
        if (message.getMessageType() != MessageType.RESPONSE) {
            return;
        }

        CompletableFuture<RpcResponse> future = PENDING_REQUESTS.remove(message.getRequestId());
        if (future != null) {
            RpcResponse response = SerializerFactory.getSerializer(message.getSerializerType())
                    .deserialize(message.getData(), RpcResponse.class);
            future.complete(response);
        }
    }

    @Override
    public void userEventTriggered(ChannelHandlerContext ctx, Object evt) {
        if (evt instanceof IdleStateEvent) {
            IdleStateEvent event = (IdleStateEvent) evt;
            if (event.state() == IdleState.ALL_IDLE) {
                ctx.close();
            }
        } else {
            ctx.fireUserEventTriggered(evt);
        }
    }

    @Override
    public void exceptionCaught(ChannelHandlerContext ctx, Throwable cause) {
        ctx.close();
    }
}
