package com.dg.rpc.core;

import com.dg.rpc.common.exception.RpcException;
import com.dg.rpc.common.trace.RpcTrace;
import com.dg.rpc.core.config.RpcClientConfig;
import com.dg.rpc.core.loadbalance.LoadBalancer;
import com.dg.rpc.core.loadbalance.RoundRobinLoadBalancer;
import com.dg.rpc.protocol.message.RpcRequest;
import com.dg.rpc.protocol.message.RpcResponse;
import com.dg.rpc.protocol.serializer.SerializerType;
import com.dg.rpc.registry.ServiceDiscovery;
import com.dg.rpc.registry.ServiceInstance;
import com.dg.rpc.transport.RpcClient;

import java.lang.reflect.InvocationHandler;
import java.lang.reflect.Method;
import java.lang.reflect.Proxy;
import java.util.List;

/**
 * RPC 客户端动态代理
 * 支持超时控制、重试机制与容错（失败快速返回、异常传播）
 */
public class RpcClientProxy implements InvocationHandler {

    private final Class<?> serviceInterface;
    private final ServiceDiscovery serviceDiscovery;
    private final LoadBalancer loadBalancer;
    private final RpcClient rpcClient;
    private final SerializerType serializerType;
    private final int retries;
    private final long retryIntervalMs;

    public RpcClientProxy(Class<?> serviceInterface, ServiceDiscovery serviceDiscovery) {
        this(serviceInterface, serviceDiscovery, new RoundRobinLoadBalancer(), new RpcClientConfig());
    }

    public RpcClientProxy(Class<?> serviceInterface, ServiceDiscovery serviceDiscovery,
                          LoadBalancer loadBalancer, RpcClientConfig config) {
        this.serviceInterface = serviceInterface;
        this.serviceDiscovery = serviceDiscovery;
        this.loadBalancer = loadBalancer;
        this.serializerType = config.getSerializerType();
        this.rpcClient = new RpcClient(this.serializerType, config.getConnectTimeoutMs(), config.getRequestTimeoutMs());
        this.retries = config.getRetries();
        this.retryIntervalMs = config.getRetryIntervalMs();
    }

    @SuppressWarnings("unchecked")
    public static <T> T createProxy(Class<T> serviceInterface, ServiceDiscovery serviceDiscovery) {
        return (T) Proxy.newProxyInstance(
                serviceInterface.getClassLoader(),
                new Class<?>[]{serviceInterface, AutoCloseable.class},
                new RpcClientProxy(serviceInterface, serviceDiscovery)
        );
    }

    @SuppressWarnings("unchecked")
    public static <T> T createProxy(Class<T> serviceInterface, ServiceDiscovery serviceDiscovery,
                                    LoadBalancer loadBalancer, RpcClientConfig config) {
        return (T) Proxy.newProxyInstance(
                serviceInterface.getClassLoader(),
                new Class<?>[]{serviceInterface, AutoCloseable.class},
                new RpcClientProxy(serviceInterface, serviceDiscovery, loadBalancer, config)
        );
    }

    @Override
    public Object invoke(Object proxy, Method method, Object[] args) throws Throwable {
        if (AutoCloseable.class.equals(method.getDeclaringClass())
                && "close".equals(method.getName())
                && method.getParameterCount() == 0) {
            rpcClient.close();
            return null;
        }
        if (Object.class.equals(method.getDeclaringClass())) {
            return method.invoke(this, args);
        }

        // trace: 动态代理拦截（真实发生的位置）
        RpcTrace.emitToCurrent(2, "enter", "RpcClientProxy.invoke");

        String serviceName = serviceInterface.getName();
        List<ServiceInstance> instances = serviceDiscovery.discover(serviceName);
        if (instances == null || instances.isEmpty()) {
            throw new RpcException("No available instance for service: " + serviceName);
        }

        ServiceInstance instance = loadBalancer.select(serviceName, instances);
        if (instance == null) {
            throw new RpcException("LoadBalancer returned null for service: " + serviceName);
        }

        RpcRequest request = new RpcRequest(
                serviceName,
                method.getName(),
                method.getParameterTypes(),
                args
        );

        int attempts = retries + 1;
        RpcResponse response = null;
        Exception lastException = null;

        for (int i = 0; i < attempts; i++) {
            try {
                response = rpcClient.sendRequest(instance.getHost(), instance.getPort(), request);
                break;
            } catch (Exception e) {
                lastException = e;
                if (i < attempts - 1 && retryIntervalMs > 0) {
                    Thread.sleep(retryIntervalMs);
                }
            }
        }

        if (response == null) {
            throw new RpcException("Request failed after " + attempts + " attempts", lastException);
        }

        if (response.hasException()) {
            throw response.getException();
        }

        Object result = response.getResult();
        if (serializerType == SerializerType.JSON) {
            return coerceJsonNumberResultIfNeeded(method.getReturnType(), result);
        }
        return result;
    }

    private static Object coerceJsonNumberResultIfNeeded(Class<?> returnType, Object result) {
        if (result == null || returnType == void.class || returnType == Void.class) {
            return null;
        }
        if (!(result instanceof Number)) {
            return result;
        }

        Number n = (Number) result;
        if (returnType == int.class || returnType == Integer.class) {
            return n.intValue();
        }
        if (returnType == long.class || returnType == Long.class) {
            return n.longValue();
        }
        if (returnType == short.class || returnType == Short.class) {
            return n.shortValue();
        }
        if (returnType == byte.class || returnType == Byte.class) {
            return n.byteValue();
        }
        if (returnType == float.class || returnType == Float.class) {
            return n.floatValue();
        }
        if (returnType == double.class || returnType == Double.class) {
            return n.doubleValue();
        }
        return result;
    }
}
