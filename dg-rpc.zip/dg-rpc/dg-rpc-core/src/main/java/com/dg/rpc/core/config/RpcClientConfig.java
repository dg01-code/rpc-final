package com.dg.rpc.core.config;

import com.dg.rpc.protocol.serializer.SerializerType;

/**
 * RPC 客户端配置
 */
public class RpcClientConfig {

    private int connectTimeoutMs = 3000;
    private int requestTimeoutMs = 5000;
    private int retries = 0;
    private long retryIntervalMs = 100;
    private SerializerType serializerType = SerializerType.HESSIAN;

    public int getConnectTimeoutMs() {
        return connectTimeoutMs;
    }

    public RpcClientConfig setConnectTimeoutMs(int connectTimeoutMs) {
        this.connectTimeoutMs = connectTimeoutMs;
        return this;
    }

    public int getRequestTimeoutMs() {
        return requestTimeoutMs;
    }

    public RpcClientConfig setRequestTimeoutMs(int requestTimeoutMs) {
        this.requestTimeoutMs = requestTimeoutMs;
        return this;
    }

    public int getRetries() {
        return retries;
    }

    public RpcClientConfig setRetries(int retries) {
        this.retries = retries;
        return this;
    }

    public long getRetryIntervalMs() {
        return retryIntervalMs;
    }

    public RpcClientConfig setRetryIntervalMs(long retryIntervalMs) {
        this.retryIntervalMs = retryIntervalMs;
        return this;
    }

    public SerializerType getSerializerType() {
        return serializerType;
    }

    public RpcClientConfig setSerializerType(SerializerType serializerType) {
        if (serializerType != null) {
            this.serializerType = serializerType;
        }
        return this;
    }
}
