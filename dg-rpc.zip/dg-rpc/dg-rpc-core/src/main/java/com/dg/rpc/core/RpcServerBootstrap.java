package com.dg.rpc.core;

import com.dg.rpc.registry.ServiceInstance;
import com.dg.rpc.registry.ServiceRegistry;
import com.dg.rpc.transport.RpcServer;

import java.util.HashMap;
import java.util.Map;

/**
 * RPC 服务端启动器
 * 负责注册服务并启动 Netty 服务端
 */
public class RpcServerBootstrap {

    private final int port;
    private final String host;
    private final ServiceRegistry serviceRegistry;
    private final Map<String, Object> serviceMap = new HashMap<>();
    private RpcServer rpcServer;

    public RpcServerBootstrap(int port, ServiceRegistry serviceRegistry) {
        this("127.0.0.1", port, serviceRegistry);
    }

    public RpcServerBootstrap(String host, int port, ServiceRegistry serviceRegistry) {
        this.host = host;
        this.port = port;
        this.serviceRegistry = serviceRegistry;
    }

    public RpcServerBootstrap registerService(String serviceName, Object serviceImpl) {
        serviceMap.put(serviceName, serviceImpl);
        return this;
    }

    public void start() {
        for (Map.Entry<String, Object> entry : serviceMap.entrySet()) {
            serviceRegistry.register(entry.getKey(), new ServiceInstance(host, port));
        }
        rpcServer = new RpcServer(port, serviceMap);
        rpcServer.start();
    }

    public void shutdown() {
        if (rpcServer != null) {
            for (String serviceName : serviceMap.keySet()) {
                serviceRegistry.unregister(serviceName, new ServiceInstance(host, port));
            }
            rpcServer.shutdown();
        }
    }
}
