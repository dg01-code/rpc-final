package com.dg.rpc.core.loadbalance;

import com.dg.rpc.registry.ServiceInstance;

import java.util.List;
import java.util.concurrent.ThreadLocalRandom;

/**
 * 随机负载均衡
 */
public class RandomLoadBalancer implements LoadBalancer {

    @Override
    public ServiceInstance select(String serviceName, List<ServiceInstance> instances) {
        if (instances == null || instances.isEmpty()) {
            return null;
        }
        int idx = ThreadLocalRandom.current().nextInt(instances.size());
        return instances.get(idx);
    }
}
