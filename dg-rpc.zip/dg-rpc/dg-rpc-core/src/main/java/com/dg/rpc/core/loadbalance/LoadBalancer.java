package com.dg.rpc.core.loadbalance;

import com.dg.rpc.registry.ServiceInstance;

import java.util.List;

/**
 * 负载均衡接口
 */
public interface LoadBalancer {

    ServiceInstance select(String serviceName, List<ServiceInstance> instances);
}
