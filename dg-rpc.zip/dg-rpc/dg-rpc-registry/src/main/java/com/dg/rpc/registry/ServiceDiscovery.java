package com.dg.rpc.registry;

import java.util.List;

/**
 * 服务发现接口
 */
public interface ServiceDiscovery {

    List<ServiceInstance> discover(String serviceName);
}
