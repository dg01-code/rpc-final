package com.dg.rpc.registry;

/**
 * 服务注册接口
 */
public interface ServiceRegistry {

    void register(String serviceName, ServiceInstance instance);

    void unregister(String serviceName, ServiceInstance instance);
}
