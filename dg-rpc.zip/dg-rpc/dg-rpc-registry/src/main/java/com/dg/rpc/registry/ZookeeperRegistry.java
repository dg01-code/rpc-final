package com.dg.rpc.registry;

import com.dg.rpc.common.exception.RpcException;
import org.apache.curator.framework.CuratorFramework;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.apache.curator.framework.CuratorFrameworkFactory;
import org.apache.curator.retry.ExponentialBackoffRetry;
import org.apache.zookeeper.CreateMode;
import org.apache.zookeeper.KeeperException;

import java.nio.charset.StandardCharsets;
import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.ConcurrentHashMap;

/**
 * 基于 Zookeeper 的注册中心实现。
 * 服务节点为持久节点，实例节点为临时节点，进程掉线后自动摘除。
 */
public class ZookeeperRegistry implements ServiceRegistry, ServiceDiscovery, AutoCloseable {

    private static final Logger log = LoggerFactory.getLogger(ZookeeperRegistry.class);

    private final CuratorFramework client;
    private final String connectString;
    private final String rootPath;
    /** key: serviceName + "|" + instance.getAddress(), value: 实例在 ZK 上的完整路径 */
    private final ConcurrentHashMap<String, String> registeredPaths = new ConcurrentHashMap<>();

    public ZookeeperRegistry(String connectString, String rootPath, int sessionTimeoutMs) {
        this.connectString = connectString;
        this.rootPath = normalizeRootPath(rootPath);
        this.client = CuratorFrameworkFactory.builder()
                .connectString(connectString)
                .sessionTimeoutMs(sessionTimeoutMs)
                .retryPolicy(new ExponentialBackoffRetry(1000, 3))
                .build();
    }

    /** 启动连接，需在 register/discover 前调用 */
    public void start() {
        log.info("Zookeeper connecting, connectString={}, rootPath={}", connectString, rootPath);
        client.start();
        try {
            client.blockUntilConnected();
        } catch (InterruptedException e) {
            Thread.currentThread().interrupt();
            throw new RpcException("Zookeeper connect interrupted", e);
        }
        log.info("Zookeeper connected successfully");
    }

    @Override
    public void close() {
        if (client != null) {
            log.info("Zookeeper registry closing");
            client.close();
        }
    }

    private static String normalizeRootPath(String rootPath) {
        if (rootPath == null || rootPath.isEmpty()) {
            return "/dg-rpc";
        }
        String p = rootPath.trim();
        if (!p.startsWith("/")) {
            p = "/" + p;
        }
        return p.endsWith("/") ? p.substring(0, p.length() - 1) : p;
    }

    private String servicePath(String serviceName) {
        return rootPath + "/" + serviceName;
    }

    private String instanceKey(String serviceName, ServiceInstance instance) {
        return serviceName + "|" + instance.getAddress();
    }

    @Override
    public void register(String serviceName, ServiceInstance instance) {
        String key = instanceKey(serviceName, instance);
        if (registeredPaths.containsKey(key)) {
            return;
        }
        String servicePath = servicePath(serviceName);
        byte[] data = instance.getAddress().getBytes(StandardCharsets.UTF_8);
        try {
            try {
                if (client.checkExists().forPath(servicePath) == null) {
                    client.create().creatingParentsIfNeeded().forPath(servicePath);
                }
            } catch (KeeperException.NodeExistsException ignored) {
            }
            String instancePath = client.create()
                    .withMode(CreateMode.EPHEMERAL_SEQUENTIAL)
                    .forPath(servicePath + "/instance-", data);
            registeredPaths.put(key, instancePath);
            log.info("Zookeeper registered: serviceName={}, instance={}, path={}", serviceName, instance.getAddress(), instancePath);
        } catch (Exception e) {
            throw new RpcException("Zookeeper register failed: " + serviceName + " -> " + instance, e);
        }
    }

    @Override
    public void unregister(String serviceName, ServiceInstance instance) {
        String key = instanceKey(serviceName, instance);
        String path = registeredPaths.remove(key);
        if (path == null) {
            return;
        }
        try {
            client.delete().forPath(path);
            log.info("Zookeeper unregistered: serviceName={}, instance={}, path={}", serviceName, instance.getAddress(), path);
        } catch (KeeperException.NoNodeException ignored) {
        } catch (Exception e) {
            throw new RpcException("Zookeeper unregister failed: " + path, e);
        }
    }

    @Override
    public List<ServiceInstance> discover(String serviceName) {
        String servicePath = servicePath(serviceName);
        List<ServiceInstance> result = new ArrayList<>();
        try {
            if (client.checkExists().forPath(servicePath) == null) {
                return result;
            }
            List<String> children = client.getChildren().forPath(servicePath);
            for (String child : children) {
                String fullPath = servicePath + "/" + child;
                byte[] data = client.getData().forPath(fullPath);
                if (data != null && data.length > 0) {
                    ServiceInstance inst = parseInstance(data);
                    if (inst != null) {
                        result.add(inst);
                    }
                }
            }
        } catch (KeeperException.NoNodeException e) {
            return result;
        } catch (Exception e) {
            throw new RpcException("Zookeeper discover failed: " + serviceName, e);
        }
        log.debug("Zookeeper discover: serviceName={}, instanceCount={}", serviceName, result.size());
        return result;
    }

    private static ServiceInstance parseInstance(byte[] data) {
        String s = new String(data, StandardCharsets.UTF_8);
        int i = s.lastIndexOf(':');
        if (i <= 0 || i >= s.length() - 1) {
            return null;
        }
        String host = s.substring(0, i);
        int port = Integer.parseInt(s.substring(i + 1));
        return new ServiceInstance(host, port);
    }
}
