package com.dg.rpc.registry;

import java.io.Serializable;
import java.util.Objects;

/**
 * 服务实例信息
 */
public class ServiceInstance implements Serializable {

    private static final long serialVersionUID = 1L;

    private String host;
    private int port;

    public ServiceInstance() {
    }

    public ServiceInstance(String host, int port) {
        this.host = host;
        this.port = port;
    }

    public String getHost() {
        return host;
    }

    public void setHost(String host) {
        this.host = host;
    }

    public int getPort() {
        return port;
    }

    public void setPort(int port) {
        this.port = port;
    }

    public String getAddress() {
        return host + ":" + port;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        ServiceInstance that = (ServiceInstance) o;
        return port == that.port && Objects.equals(host, that.host);
    }

    @Override
    public int hashCode() {
        return Objects.hash(host, port);
    }

    @Override
    public String toString() {
        return getAddress();
    }
}
