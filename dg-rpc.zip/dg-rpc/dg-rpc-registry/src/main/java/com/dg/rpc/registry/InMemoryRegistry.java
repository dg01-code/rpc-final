package com.dg.rpc.registry;

import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.CopyOnWriteArrayList;

/**
 * 内存注册中心实现，用于演示和单元测试
 */
public class InMemoryRegistry implements ServiceRegistry, ServiceDiscovery {

    private final ConcurrentHashMap<String, List<ServiceInstance>> registry = new ConcurrentHashMap<>();

    @Override
    public void register(String serviceName, ServiceInstance instance) {
        registry.computeIfAbsent(serviceName, k -> new CopyOnWriteArrayList<>())
                .add(instance);
    }

    @Override
    public void unregister(String serviceName, ServiceInstance instance) {
        List<ServiceInstance> list = registry.get(serviceName);
        if (list != null) {
            list.remove(instance);
        }
    }

    @Override
    public List<ServiceInstance> discover(String serviceName) {
        List<ServiceInstance> list = registry.get(serviceName);
        return list != null ? new ArrayList<>(list) : new ArrayList<>();
    }
}
